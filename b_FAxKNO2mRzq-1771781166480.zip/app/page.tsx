import { PlatformCards } from "@/components/platform-cards"
import { FloatingParticles } from "@/components/floating-particles"

export default function Home() {
  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-background">
      <FloatingParticles />
      <main className="relative z-10 w-full px-4">
        <PlatformCards />
      </main>
    </div>
  )
}
