"use client"

import { Monitor, Globe, Smartphone, Apple } from "lucide-react"
import type { LucideIcon } from "lucide-react"

interface Platform {
  name: string
  subtitle: string
  icon: LucideIcon
  href: string
}

const platforms: Platform[] = [
  {
    name: "Oculus / Android",
    subtitle: "VR & Mobile",
    icon: Smartphone,
    href: "https://example.com",
  },
  {
    name: "Web",
    subtitle: "Play in Browser",
    icon: Globe,
    href: "https://example.com",
  },
  {
    name: "Windows",
    subtitle: "PC Download",
    icon: Monitor,
    href: "https://example.com",
  },
  {
    name: "Mac",
    subtitle: "macOS Download",
    icon: Apple,
    href: "https://example.com",
  },
]

function PlatformCard({ platform }: { platform: Platform }) {
  return (
    <a
      href={platform.href}
      target="_blank"
      rel="noopener noreferrer"
      className="group relative flex flex-col items-center gap-4 p-8 rounded-2xl
        bg-white/[0.03] border border-white/[0.07]
        backdrop-blur-2xl
        shadow-[0_4px_30px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.05)]
        transition-all duration-500 ease-out
        hover:bg-white/[0.07] hover:border-[#ffd521]/20
        hover:shadow-[0_8px_50px_rgba(255,213,33,0.1),inset_0_1px_0_rgba(255,255,255,0.1)]
        hover:-translate-y-2
        focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#ffd521]/50 focus-visible:ring-offset-2 focus-visible:ring-offset-[#0a0a14]"
      aria-label={`Download Bart Blast for ${platform.name}`}
    >
      {/* Glass shine overlay */}
      <div className="absolute inset-0 rounded-2xl overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-white/[0.06] to-transparent rotate-12 group-hover:from-white/[0.1] transition-all duration-500" />
      </div>

      {/* Subtle inner glow on hover */}
      <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none
        bg-gradient-to-b from-[#ffd521]/[0.04] via-transparent to-transparent" />

      {/* Icon container */}
      <div className="relative flex items-center justify-center w-16 h-16 rounded-xl
        bg-white/[0.05] border border-white/[0.08]
        backdrop-blur-xl
        shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]
        group-hover:bg-[#ffd521]/10 group-hover:border-[#ffd521]/20
        group-hover:shadow-[0_0_25px_rgba(255,213,33,0.1),inset_0_1px_0_rgba(255,213,33,0.1)]
        transition-all duration-500 group-hover:scale-110">
        <platform.icon className="w-8 h-8 text-white/50 group-hover:text-[#ffd521] transition-colors duration-300" strokeWidth={1.5} />
      </div>

      {/* Text */}
      <div className="text-center relative">
        <h3 className="font-[family-name:var(--font-display)] text-xl tracking-wide text-white/80 group-hover:text-[#ffd521] transition-colors duration-300">
          {platform.name}
        </h3>
        <p className="mt-1 text-sm text-white/30 group-hover:text-white/50 transition-colors duration-300">
          {platform.subtitle}
        </p>
      </div>

      {/* Arrow indicator */}
      <div className="flex items-center justify-center w-8 h-8 rounded-full
        bg-white/[0.04] border border-white/[0.06]
        group-hover:bg-[#ffd521]/10 group-hover:border-[#ffd521]/20
        transition-all duration-300">
        <svg
          className="w-4 h-4 text-white/30 group-hover:text-[#ffd521] group-hover:translate-x-0.5 transition-all duration-300"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
          aria-hidden="true"
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
        </svg>
      </div>
    </a>
  )
}

export function PlatformCards() {
  return (
    <section className="relative">
      <div className="max-w-5xl mx-auto flex flex-col items-center gap-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 w-full">
          {platforms.map((platform) => (
            <PlatformCard key={platform.name} platform={platform} />
          ))}
        </div>

        {/* Discord Button */}
        <a
          href="https://discord.gg/example"
          target="_blank"
          rel="noopener noreferrer"
          className="group relative inline-flex items-center gap-3 px-8 py-4 rounded-2xl
            bg-[#5865F2]/10 border border-[#5865F2]/20
            backdrop-blur-2xl
            shadow-[0_4px_30px_rgba(88,101,242,0.1),inset_0_1px_0_rgba(255,255,255,0.05)]
            transition-all duration-500 ease-out
            hover:bg-[#5865F2]/20 hover:border-[#5865F2]/40
            hover:shadow-[0_8px_50px_rgba(88,101,242,0.2),inset_0_1px_0_rgba(255,255,255,0.1)]
            hover:-translate-y-1
            focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5865F2]/50 focus-visible:ring-offset-2 focus-visible:ring-offset-[#0a0a14]"
          aria-label="Join our Discord server"
        >
          <div className="absolute inset-0 rounded-2xl overflow-hidden pointer-events-none">
            <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-white/[0.04] to-transparent rotate-12 group-hover:from-white/[0.08] transition-all duration-500" />
          </div>
          <svg className="relative w-6 h-6 text-[#5865F2] group-hover:text-[#7289da] transition-colors duration-300" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189z" />
          </svg>
          <span className="relative font-[family-name:var(--font-display)] text-lg tracking-wide text-[#5865F2] group-hover:text-[#7289da] transition-colors duration-300">
            Join our Discord
          </span>
        </a>
      </div>
    </section>
  )
}
